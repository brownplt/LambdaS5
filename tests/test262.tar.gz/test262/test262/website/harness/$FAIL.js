function $FAIL(message) {
    testFailed(message);
}
