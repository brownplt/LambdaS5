//function Test262Error(message) {
//    if (message) this.message = message;
//}
//
//Test262Error.prototype.toString = function () {
//    return "Test262 Error: " + this.message;
//};
