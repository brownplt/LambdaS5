//adaptors for Test262 framework
function $PRINT(message) {

}
