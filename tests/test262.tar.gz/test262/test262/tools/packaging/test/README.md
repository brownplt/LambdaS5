# Unit tests for python packaging tools

This directory holds tests for the python code, not tests of EMCAScript

## Running tests

````
$ cd tools/packaging/test
$ python test*.py
````

